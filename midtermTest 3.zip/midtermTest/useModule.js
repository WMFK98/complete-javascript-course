import { sum as price } require './Fmodule.js';

mos(10);
console.log(getPrice());
