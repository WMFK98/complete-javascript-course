function ProductManagement() {
  const products = [];
  //add products variable here

  function getAllProducts() {
    return products;
  } //,,

  function addProduct(product) {
    products.push(product);
  }

  function searchByName(name = '') {
    return products.filter(
      ({ name: nameProduct }) =>
        name.toLowerCase() === nameProduct.toLowerCase()
    );
  }

  function searchByPriceRange(minPrice, maxPrice) {
    return products.filter(
      ({ price }) => price >= minPrice && price <= maxPrice
    );
  }

  function removeAll() {
    products.splice(0, products.length);
  }

  return {
    removeAll,
    searchByName,
    searchByPriceRange,
    getAllProducts,
    addProduct,
  };
}
module.exports = ProductManagement;
const productCatalog = ProductManagement();

// const product2 = {
//   id: 2,
//   name: 'T-shirt',
//   category: 'Clothing',
//   price: 19.99,
// };

// productCatalog.addProduct(product2);
// console.log(productCatalog.getAllProducts());
// console.log(productCatalog.searchByName('t-shirt'));
// console.log(productCatalog.searchByPriceRange(15, 20));
// productCatalog.removeAll();
// console.log(productCatalog.getAllProducts());
