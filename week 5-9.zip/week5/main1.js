const obj = {
    name: 'name'
}
console.log(Object.keys(obj).length === 0);
