import sgg from './shoppingCart';

console.log(sgg.);
