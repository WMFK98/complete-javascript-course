// console.log('hello');
// const person = {
//   name: 'John',
//   age: 30,
// };
// console.log(person);

// const personPrototype = {
//   greet: function () {
//     console.log('Hello!');
//   },
// };
// const john = Object.create(personPrototype);
// console.log(personPrototype);
// john.name = 'fluke';

// console.log();

// class Person {
//   kuy = 9;
//   constructor(name, age) {
//     this.name = name;
//     this.age = age;
//   }
// }
// const Mos = new Person('Mos', 88);

// const john = new Person('John', 30);

// function createPerson(name, age) {
//   return {
//     name,
//     age,
//   };
// }

// const pohn = createPerson('pohn', 30);

// console.log(pohn);

// const person = new Object();
// person.name = 'Jay';
// person.age = 30;

// console.log(person.prototype);

// const person = {
//   name: 'leng',
//   callthis() {
//     console.log(this);
//   },
//   callthisButArrow: () => console.log(this),
// };
// callMeEveryWhere(1);

// function callMeEveryWhere(name) {
//   console.log("I'm here " + name);
// }
// callMeEveryWhere(2);

// const callMeOnlyBelow = function (name) {
//   console.log("yeah It'me " + name);
// };

// const callMeOnlyBelow2 = (name) => console.log("yeah It'me " + name);

// callMeOnlyBelow2(2);

// return new Array
// console.log(Array.of(5));
// const array = [1, 2, 3, 4];
// const array2 = Array.from(array);
// console.log(array2);
// array2.push(5);
// console.log(array2);
